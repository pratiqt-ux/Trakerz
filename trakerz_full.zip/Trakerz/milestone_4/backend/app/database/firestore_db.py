"""
Cloud Firestore Implementation of BaseExpenseDatabase for Milestone 4.
Supports Expenses, Monthly Budgets, Savings Goals, Contributions, and Chart Analytics
in Google Cloud Firestore.
"""
import os
import calendar
from datetime import datetime
from typing import List, Optional, Dict, Any
from app.database.base import BaseExpenseDatabase


class FirestoreExpenseDatabase(BaseExpenseDatabase):
    def __init__(self, credentials_path: str, project_id: Optional[str] = None, collection_name: str = "expenses"):
        self.credentials_path = credentials_path
        self.project_id = project_id
        self.collection_name = collection_name
        self.client = None
        self.initialize()

    def initialize(self) -> None:
        try:
            from google.cloud import firestore
            from google.oauth2 import service_account
        except ImportError:
            raise RuntimeError(
                "google-cloud-firestore is not installed. Run: pip install google-cloud-firestore"
            )

        if not self.credentials_path or not os.path.exists(self.credentials_path):
            raise FileNotFoundError(
                f"Cloud Firestore credentials file not found: '{self.credentials_path}'. "
                "Ensure GOOGLE_APPLICATION_CREDENTIALS points to a valid JSON service account key."
            )

        try:
            credentials = service_account.Credentials.from_service_account_file(self.credentials_path)
            self.client = firestore.Client(
                credentials=credentials,
                project=self.project_id or credentials.project_id
            )
        except Exception as e:
            raise ConnectionError(f"Failed to connect to Cloud Firestore: {str(e)}")

    def _get_collection(self, name: Optional[str] = None):
        if not self.client:
            raise RuntimeError("Firestore client is not connected.")
        return self.client.collection(name or self.collection_name)

    # ==========================================================
    # EXPENSES
    # ==========================================================

    def create_expense(self, data: Dict[str, Any]) -> Dict[str, Any]:
        col = self._get_collection()
        created_at = data.get("created_at") or datetime.now().isoformat()

        doc_data = {
            "category": data["category"],
            "amount": float(data["amount"]),
            "description": data.get("description", ""),
            "date": data["date"],
            "created_at": created_at
        }

        doc_ref = col.document()
        doc_ref.set(doc_data)

        doc_data["id"] = doc_ref.id
        return doc_data

    def get_expenses(self, limit: Optional[int] = None) -> List[Dict[str, Any]]:
        col = self._get_collection()
        query = col.order_by("date", direction="DESCENDING")
        if limit:
            query = query.limit(limit)

        docs = query.stream()
        results = []
        for doc in docs:
            item = doc.to_dict()
            item["id"] = doc.id
            item["amount"] = float(item.get("amount", 0.0))
            item["description"] = item.get("description") or ""
            results.append(item)
        return results

    def get_expense(self, expense_id: str) -> Optional[Dict[str, Any]]:
        col = self._get_collection()
        doc = col.document(expense_id).get()
        if not doc.exists:
            return None
        item = doc.to_dict()
        item["id"] = doc.id
        item["amount"] = float(item.get("amount", 0.0))
        item["description"] = item.get("description") or ""
        return item

    def update_expense(self, expense_id: str, data: Dict[str, Any]) -> Optional[Dict[str, Any]]:
        col = self._get_collection()
        doc_ref = col.document(expense_id)
        doc = doc_ref.get()
        if not doc.exists:
            return None

        update_fields = {}
        for key in ["category", "amount", "description", "date"]:
            if key in data and data[key] is not None:
                update_fields[key] = float(data[key]) if key == "amount" else data[key]

        if update_fields:
            doc_ref.update(update_fields)

        updated = doc_ref.get().to_dict()
        updated["id"] = expense_id
        updated["amount"] = float(updated.get("amount", 0.0))
        return updated

    def delete_expense(self, expense_id: str) -> bool:
        col = self._get_collection()
        doc_ref = col.document(expense_id)
        doc = doc_ref.get()
        if not doc.exists:
            return False
        doc_ref.delete()
        return True

    def get_total_expense(self) -> float:
        expenses = self.get_expenses()
        total = sum(e.get("amount", 0.0) for e in expenses)
        return round(float(total), 2)

    def get_category_totals(self) -> List[Dict[str, Any]]:
        expenses = self.get_expenses()
        total_spending = sum(e.get("amount", 0.0) for e in expenses)

        cat_map: Dict[str, Dict[str, Any]] = {}
        for e in expenses:
            cat = e.get("category", "Other")
            amt = float(e.get("amount", 0.0))
            if cat not in cat_map:
                cat_map[cat] = {"total": 0.0, "count": 0}
            cat_map[cat]["total"] += amt
            cat_map[cat]["count"] += 1

        results = []
        for cat, val in cat_map.items():
            cat_total = round(val["total"], 2)
            pct = round((cat_total / total_spending * 100), 1) if total_spending > 0 else 0.0
            results.append({
                "category": cat,
                "total": cat_total,
                "percentage": pct,
                "count": val["count"]
            })

        results.sort(key=lambda x: x["total"], reverse=True)
        return results

    def get_monthly_totals(self) -> List[Dict[str, Any]]:
        expenses = self.get_expenses()
        current_ym = datetime.now().strftime("%Y-%m")

        month_map: Dict[str, Dict[str, Any]] = {}
        for e in expenses:
            ym = str(e.get("date", ""))[:7] or "Unknown"
            amt = float(e.get("amount", 0.0))
            if ym not in month_map:
                month_map[ym] = {"total": 0.0, "count": 0}
            month_map[ym]["total"] += amt
            month_map[ym]["count"] += 1

        results = []
        for ym, val in month_map.items():
            results.append({
                "month": ym,
                "total": round(val["total"], 2),
                "count": val["count"],
                "is_current_month": (ym == current_ym)
            })

        results.sort(key=lambda x: x["month"], reverse=True)
        return results

    def get_backend_info(self) -> Dict[str, Any]:
        return {
            "mode": "cloud",
            "database_type": "firestore",
            "status": "connected" if self.client else "disconnected",
            "project_id": self.project_id,
            "collection": self.collection_name,
            "cloud_configured": True
        }

    # ==========================================================
    # BUDGETS (Firestore 'budgets' collection)
    # ==========================================================

    def _compute_budget_fields(self, b_id: str, b_data: Dict[str, Any], expenses: List[Dict[str, Any]]) -> Dict[str, Any]:
        cat = b_data["category"]
        m = b_data["month"]
        b_amt = float(b_data["amount"])

        spent = round(sum(
            float(e.get("amount", 0.0))
            for e in expenses
            if e.get("category") == cat and str(e.get("date", "")).startswith(m)
        ), 2)

        remaining = round(b_amt - spent, 2)
        pct = round((spent / b_amt * 100), 1) if b_amt > 0 else 0.0
        overspent = round(spent - b_amt, 2) if spent > b_amt else 0.0

        if pct >= 100.0:
            status = "exceeded"
        elif pct >= 80.0:
            status = "warning"
        else:
            status = "normal"

        return {
            "id": b_id,
            "category": cat,
            "month": m,
            "amount": b_amt,
            "spent_amount": spent,
            "remaining_amount": remaining,
            "percentage_used": pct,
            "status": status,
            "overspent_amount": overspent,
            "created_at": b_data.get("created_at")
        }

    def upsert_budget(self, data: Dict[str, Any]) -> Dict[str, Any]:
        col = self._get_collection("budgets")
        # Deterministic doc ID per category+month to prevent duplicates
        safe_cat = data["category"].strip().lower().replace("/", "_")
        doc_id = f"{data['month']}_{safe_cat}"
        doc_ref = col.document(doc_id)
        existing = doc_ref.get()

        created_at = existing.to_dict().get("created_at") if existing.exists else datetime.now().isoformat()
        payload = {
            "category": data["category"],
            "month": data["month"],
            "amount": float(data["amount"]),
            "created_at": created_at
        }
        doc_ref.set(payload)
        expenses = self.get_expenses()
        return self._compute_budget_fields(doc_id, payload, expenses)

    def get_budgets(self, month: Optional[str] = None) -> List[Dict[str, Any]]:
        col = self._get_collection("budgets")
        docs = col.stream()
        expenses = self.get_expenses()

        results = []
        for doc in docs:
            b = doc.to_dict()
            if month and b.get("month") != month:
                continue
            results.append(self._compute_budget_fields(doc.id, b, expenses))

        results.sort(key=lambda x: x["category"])
        return results

    def get_budget_by_id(self, budget_id: str) -> Optional[Dict[str, Any]]:
        col = self._get_collection("budgets")
        doc = col.document(budget_id).get()
        if not doc.exists:
            return None
        expenses = self.get_expenses()
        return self._compute_budget_fields(doc.id, doc.to_dict(), expenses)

    def delete_budget(self, budget_id: str) -> bool:
        col = self._get_collection("budgets")
        doc_ref = col.document(budget_id)
        if not doc_ref.get().exists:
            return False
        doc_ref.delete()
        return True

    # ==========================================================
    # SAVINGS GOALS & CONTRIBUTIONS (Firestore collections)
    # ==========================================================

    def create_savings_goal(self, data: Dict[str, Any]) -> Dict[str, Any]:
        col = self._get_collection("savings_goals")
        created_at = datetime.now().isoformat()
        payload = {
            "title": data["title"],
            "target_amount": float(data["target_amount"]),
            "deadline": data.get("deadline"),
            "category": data.get("category", "General"),
            "is_completed": bool(data.get("is_completed", False)),
            "created_at": created_at
        }
        doc_ref = col.document()
        doc_ref.set(payload)
        return self.get_savings_goal(doc_ref.id)

    def get_savings_goals(self) -> List[Dict[str, Any]]:
        col = self._get_collection("savings_goals")
        docs = col.stream()
        results = []
        for doc in docs:
            g = self.get_savings_goal(doc.id)
            if g:
                results.append(g)
        results.sort(key=lambda x: (x["is_completed"], x.get("created_at") or ""), reverse=False)
        return results

    def get_savings_goal(self, goal_id: str) -> Optional[Dict[str, Any]]:
        col = self._get_collection("savings_goals")
        doc = col.document(goal_id).get()
        if not doc.exists:
            return None

        r = doc.to_dict()
        contribs = self.get_contributions_for_goal(goal_id)
        saved = round(sum(c["amount"] for c in contribs), 2)
        target = float(r.get("target_amount", 0.0))
        remaining = round(max(0.0, target - saved), 2)
        pct = round(min(100.0, (saved / target * 100)), 1) if target > 0 else 0.0
        is_completed = bool(r.get("is_completed", False)) or (saved >= target and target > 0)

        return {
            "id": doc.id,
            "title": r["title"],
            "target_amount": target,
            "deadline": r.get("deadline"),
            "category": r.get("category") or "General",
            "is_completed": is_completed,
            "saved_amount": saved,
            "remaining_amount": remaining,
            "progress_percentage": pct,
            "contributions": contribs,
            "created_at": r.get("created_at")
        }

    def update_savings_goal(self, goal_id: str, data: Dict[str, Any]) -> Optional[Dict[str, Any]]:
        col = self._get_collection("savings_goals")
        doc_ref = col.document(goal_id)
        if not doc_ref.get().exists:
            return None

        update_fields = {}
        for k in ["title", "target_amount", "deadline", "category", "is_completed"]:
            if k in data and data[k] is not None:
                update_fields[k] = float(data[k]) if k == "target_amount" else data[k]

        if update_fields:
            doc_ref.update(update_fields)
        return self.get_savings_goal(goal_id)

    def delete_savings_goal(self, goal_id: str) -> bool:
        col = self._get_collection("savings_goals")
        doc_ref = col.document(goal_id)
        if not doc_ref.get().exists:
            return False
        doc_ref.delete()
        # Clean up related contributions
        c_col = self._get_collection("savings_contributions")
        for c_doc in c_col.where("goal_id", "==", goal_id).stream():
            c_doc.reference.delete()
        return True

    def add_savings_contribution(self, goal_id: str, data: Dict[str, Any]) -> Dict[str, Any]:
        c_col = self._get_collection("savings_contributions")
        created_at = datetime.now().isoformat()
        payload = {
            "goal_id": goal_id,
            "amount": float(data["amount"]),
            "note": data.get("note", ""),
            "date": data["date"],
            "created_at": created_at
        }
        doc_ref = c_col.document()
        doc_ref.set(payload)

        goal = self.get_savings_goal(goal_id)
        if goal and goal["saved_amount"] >= goal["target_amount"]:
            self.update_savings_goal(goal_id, {"is_completed": True})

        payload["id"] = doc_ref.id
        return payload

    def get_contributions_for_goal(self, goal_id: str) -> List[Dict[str, Any]]:
        c_col = self._get_collection("savings_contributions")
        docs = c_col.where("goal_id", "==", goal_id).stream()
        results = []
        for doc in docs:
            c = doc.to_dict()
            c["id"] = doc.id
            c["amount"] = float(c.get("amount", 0.0))
            results.append(c)
        results.sort(key=lambda x: x.get("date", ""), reverse=True)
        return results

    def delete_savings_contribution(self, contrib_id: str) -> bool:
        c_col = self._get_collection("savings_contributions")
        doc_ref = c_col.document(contrib_id)
        if not doc_ref.get().exists:
            return False
        doc_ref.delete()
        return True

    # ==========================================================
    # CHARTS & INSIGHTS
    # ==========================================================

    def get_daily_spending(self, month: str) -> List[Dict[str, Any]]:
        try:
            year, m = map(int, month.split("-"))
            num_days = calendar.monthrange(year, m)[1]
        except Exception:
            num_days = 31

        expenses = self.get_expenses()
        day_map: Dict[str, List[float]] = {}
        for e in expenses:
            dt = str(e.get("date", ""))
            if dt.startswith(month):
                if dt not in day_map:
                    day_map[dt] = [0.0, 0]
                day_map[dt][0] += float(e.get("amount", 0.0))
                day_map[dt][1] += 1

        days_data = []
        for day in range(1, num_days + 1):
            date_str = f"{month}-{day:02d}"
            try:
                dt_obj = datetime.strptime(date_str, "%Y-%m-%d")
                day_name = dt_obj.strftime("%a")
            except Exception:
                day_name = ""
            amt, cnt = day_map.get(date_str, (0.0, 0))
            days_data.append({
                "date": date_str,
                "day": day,
                "day_name": day_name,
                "amount": round(amt, 2),
                "transaction_count": cnt
            })
        return days_data

    def get_monthly_trend(self, limit: int = 12) -> List[Dict[str, Any]]:
        expenses = self.get_expenses()
        month_map: Dict[str, List[float]] = {}
        for e in expenses:
            ym = str(e.get("date", ""))[:7]
            if not ym:
                continue
            if ym not in month_map:
                month_map[ym] = [0.0, 0]
            month_map[ym][0] += float(e.get("amount", 0.0))
            month_map[ym][1] += 1

        results = []
        for ym in sorted(month_map.keys()):
            amt, cnt = month_map[ym]
            try:
                display = datetime.strptime(ym, "%Y-%m").strftime("%b %Y")
            except Exception:
                display = ym
            results.append({
                "month": ym,
                "display_name": display,
                "amount": round(amt, 2),
                "transaction_count": int(cnt)
            })

        if limit and len(results) > limit:
            results = results[-limit:]
        return results

    def get_category_totals_for_month(self, month: str) -> List[Dict[str, Any]]:
        expenses = self.get_expenses()
        cat_map: Dict[str, List[float]] = {}
        for e in expenses:
            dt = str(e.get("date", ""))
            if dt.startswith(month):
                cat = e.get("category", "Other")
                if cat not in cat_map:
                    cat_map[cat] = [0.0, 0]
                cat_map[cat][0] += float(e.get("amount", 0.0))
                cat_map[cat][1] += 1

        month_total = sum(v[0] for v in cat_map.values())
        results = []
        for cat, val in cat_map.items():
            amt = round(val[0], 2)
            pct = round((amt / month_total * 100), 1) if month_total > 0 else 0.0
            results.append({
                "category": cat,
                "total": amt,
                "percentage": pct,
                "count": int(val[1])
            })
        results.sort(key=lambda x: x["total"], reverse=True)
        return results
