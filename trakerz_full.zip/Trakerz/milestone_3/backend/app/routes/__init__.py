"""
Routes package initialization.
"""
